const test = require('node:test');
const assert = require('node:assert/strict');
const { MatchesService } = require('../dist/matches/matches.service.js');

const service = new MatchesService();

const profile = {
  age: 25,
  educationLevel: 'bachelor',
  fieldOfStudy: 'Computer Science',
  country: 'Syria',
  languages: ['Arabic', 'English'],
  budget: 0,
};

const scholarship = (overrides = {}) => ({
  id: 1,
  title: 'Computer Science Scholarship',
  deadline: '2026-12-31',
  deadlineStatus: 'open',
  fundingLevel: 'fully_funded',
  requirements: {
    minAge: 18,
    maxAge: 30,
    requiredEducationLevel: 'bachelor',
    fieldOfStudy: 'Computer Science',
    requiredLanguages: ['Arabic', 'English'],
  },
  preferences: {
    country: 'Syria',
    fieldOfStudy: 'Computer Science',
    remainingCost: 0,
  },
  ...overrides,
});

test('high match is eligible and scores 100 when all preferences match', () => {
  const result = service.calculate(profile, scholarship());
  assert.equal(result.eligible, true);
  assert.equal(result.score, 100);
  assert.deepEqual(result.missingRequirements, []);
});

test('age bounds are inclusive', () => {
  const atMinimum = service.calculate(
    { ...profile, age: 18 },
    scholarship(),
  );
  const atMaximum = service.calculate(
    { ...profile, age: 30 },
    scholarship(),
  );
  assert.equal(atMinimum.eligible, true);
  assert.equal(atMaximum.eligible, true);
});

test('missing each required language is explained', () => {
  const result = service.calculate(
    { ...profile, languages: ['Arabic'] },
    scholarship(),
  );
  assert.equal(result.eligible, false);
  assert.ok(
    result.missingRequirements.some((reason) =>
      reason.includes('English'),
    ),
  );
  assert.ok(result.score <= 49);
});

test('unrestricted age is treated as met', () => {
  const result = service.calculate(
    { ...profile, age: 150 },
    scholarship({
      requirements: {
        minAge: null,
        maxAge: null,
        requiredEducationLevel: 'bachelor',
        fieldOfStudy: 'Computer Science',
        requiredLanguages: ['Arabic', 'English'],
      },
    }),
  );
  assert.equal(result.eligible, true);
});

test('zero budget and zero remaining cost satisfy affordability', () => {
  const result = service.calculate(
    { ...profile, budget: 0 },
    scholarship({ preferences: {
      country: 'Syria',
      fieldOfStudy: 'Computer Science',
      remainingCost: 0,
    }}),
  );
  assert.equal(result.scoreBreakdown.preferencesMet, 3);
});

test('closed scholarships are excluded and ranks are assigned before filters', () => {
  const results = service.getMatches(profile, [
    scholarship({ id: 1 }),
    scholarship({
      id: 2,
      title: 'Another scholarship',
      deadline: '2026-11-30',
      preferences: {
        country: 'Other country',
        fieldOfStudy: 'Computer Science',
        remainingCost: 0,
      },
    }),
    scholarship({ id: 3, deadlineStatus: 'closed' }),
  ], { country: 'Other country' });

  assert.equal(results.totalOpen, 2);
  assert.equal(results.eligibleCount, 2);
  assert.equal(results.total, 1);
  assert.equal(results.items[0].id, 2);
  assert.equal(results.items[0].rank, 1);
});

test('same inputs produce deterministic scores', () => {
  const first = service.calculate(profile, scholarship());
  const second = service.calculate(profile, scholarship());
  assert.deepEqual(first, second);
});
